module.exports = {
    emailRegex: /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/,
    usernameRegex: /^[a-zA-Z]\w{2,14}$/,
    passwordRegex: /^[a-zA-Z]\w{3,14}$/,
}